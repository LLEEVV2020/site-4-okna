<div class="es14_bg_custom">
            <div class="h2">
                ОТЗЫВЫ НАШИХ ЗАКАЗЧИКОВ
            </div>
            <div class="container">
                <section class="regular slider">
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Ольга Иваненко</h5>
                                <p>Я осталась очень довольна! Шкаф идеально подошел к интерьеру и другой мебели, надежный, функциональный и красивый!
                                        Замерщик снял точные мерки, посоветовал, на что обратить внимание, дал свои рекомендации по наилучшему расположению и количеству полок, зеркал и ящиков, в итоге результат оправдал все наши ожидания!
                                        Спасибо вам за нашу радость, спасибо за наш шкаф!
                                        </p>
                            </div>
                        </div>
                        
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Максим Гладков </h5>
                                <p>Все подсказали, помогли с выбором, сделали качественно и быстро. Буду 100% рекомендовать вас друзьям и родственникам. </p>
                            </div>
                        </div>
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Вероника Сыроварова </h5>
                                <p>Ребята, спасибо! Шкаф в нашей прихожей стоит как влитой, как будто всегда там и был!)) Наконец разложили все вещи, и место еще осталось!)) Как надумаем обновить шкаф в спальне, снова к вам и только к вам!  </p>
                            </div>
                        </div>
                        
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Регина Казанцева </h5>
                                <p>Заказали у вас шкаф для бабушки нашей. Она поначалу не хотела, потому что привыкла к своим вещам, не хотела изменять обстановку. Теперь благодарит очень и радуется новому шкафу. Спасибо за профессионализм и быструю работу. </p>
                            </div>
                        </div>
                        
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Егор Василевич </h5>
                                <p>Сделали заказ в вашей компании на прихожую и шкаф в гостиную. Отличная ценовая политика, быстро, качественно. Жена рада, что красиво, я – что добротно. В общем, угодили всем, молодцы! </p>
                            </div> 
                        </div>
                        
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Ольга Иваненко</h5>
                                <p>Я осталась очень довольна! Шкаф идеально подошел к интерьеру и другой мебели, надежный, функциональный и красивый!
                                        Замерщик снял точные мерки, посоветовал, на что обратить внимание, дал свои рекомендации по наилучшему расположению и количеству полок, зеркал и ящиков, в итоге результат оправдал все наши ожидания!
                                        Спасибо вам за нашу радость, спасибо за наш шкаф!
                                        </p>
                            </div>
                        </div>
                        
                    </div>
                </section>
            </div>
        </div>
<script src="//<?php echo $_SERVER['SERVER_NAME']; ?>/js/slick.min.js"></script>
 <script type="text/javascript">
            $(document).ready(function(){
                $(".regular").slick({
                    dots: true,
                    arrows: false,
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    responsive: [
                        {
                        breakpoint: 1200,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                            }
                        }
                    ]
                });
            });
            
        </script>
