   <div class="map-wrapper">
            <div id="BX_YMAP_officemap" class="bx-yandex-map" style="height: 600px; width: 100%;">
                <!--<script src="//api-maps.yandex.ru/2.1/?lang=ru_RU" type="text/javascript"></script>
                <script> ymapload(); </script>-->
                <script type="text/javascript" charset="utf-8" async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3A9d14d9c0d85cd2824bd69ab278785152b2ea09dc993729b5997fc68b5b343978&amp;width=100%25&amp;height=600&amp;lang=ru_RU&amp;scroll=true"></script>
            </div>
        </div>