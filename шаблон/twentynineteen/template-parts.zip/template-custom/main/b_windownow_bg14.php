        <div class="b_windownow_bg">

            <div class="container">

                <div class="flex-container">
                    <div class="b_windownow_man"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/b_windownow_man.png" alt=""></div>
                    <div class="b_windownow_block">
                        <h4>ШКАФ СЕЙЧАС – ОПЛАТА ПОСЛЕ</h4>
                        <div class="flex-block">
                            <div class="b_windownow_proc"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/b_windownow_proc.png" alt=""></div>
    
                            <div class="b_windownow_text">
                                <p>Рассрочка без предоплаты</p>  

                                <a href="//<?php echo $_SERVER['SERVER_NAME']; ?>/aktsii-i-skidki" class="b_windownow__btn">ХОЧУ УЗНАТЬ ПОДРОБНОСТИ!</a>
                                
                            </div>
                        </div>
                        
                    </div>
                    
                </div> 

                

            </div><!-- /.container -->

        </div>