  <!--/ Второй блок. Самый верхний блок  -->
        <div class="es2 es2_balcons template">
            <div class="container">
                <!-- $$$$$$$ -->
            <!-- $$$$$$$ -->
            <!-- $$$$$$$ -->

            <div class="h2">
                </script>
                <i id="akcia" style="font-style: normal;"></i>
                ЛУЧШИЕ ЦЕНЫ НА БАЛКОНЫ В МОСКВЕ
                </div>
                <!-- $$$$$$$ -->
                <!-- $$$$$$$ -->
                <!-- $$$$$$$ -->
                <div class="es2_block">
    
    
                    <div class="es2_oknatseny">
                        <div class="es2_oknatseny__zag"><img src="img/logo_es2.png" alt=""></div>
                        <div class="es2_but" data-toggle="modal" data-target="#kupitDeshevle">ЗАКАЗАТЬ ПО
                                ЛУЧШЕЙ ЦЕНЕ</div>
                        
                        <div class="es2_oknatseny_row">
                            <div class="es2_oknatseny_row_left">
                                    Балконы
                            </div>
                            <div class="es2_oknatseny_row_right es2_red">2310 <span>р.</span></div>
                        </div>
    
                        <div class="es2_oknatseny_row">
                            <div class="es2_oknatseny_row_left">
                                    Цена
установки
                            </div>
                            <div class="es2_oknatseny_row_right es2_red">1030 <span>р.</span></div>
                        </div>
                        <div class="es2_oknatseny_row">
                            <div class="es2_oknatseny_row_left">
                                    Разработчик
профиля
                            </div>
                            <div class="es2_oknatseny_row_right es2_red"> <span class="es2_oknatseny_row_right_text">Германия</span></div>
                        </div>
                        <div class="es2_oknatseny_row">
                            <div class="es2_oknatseny_row_left">
                                Качество
                            </div>
                            <div class="es2_oknatseny_row_right es2_oknatseny_row_right_stars">
                                <img src="img/es11_star.png" alt="">
                                <img src="img/es11_star.png" alt="">
                                <img src="img/es11_star.png" alt="">
                                <img src="img/es11_star.png" alt="">
                                <img src="img/es11_star.png" alt="">
                            </div>
                        </div>
                        <div class="es2_oknatseny_row">
                            <div class="es2_oknatseny_row_left">
                                Стеклопакет
                            </div>
                            <div class="es2_oknatseny_row_right es2_red">3 стекла</div>
                        </div>
    
    
                    </div>
    
                    <div class="es2_bgtransper"></div>
    
    
                    <div class='iosslider_2'>
    
                        <div class='slider'>
    
    
                            <div class="es2_okna slide">
                                <div class="es2_okna__zag">ДИЛЕРЫ ПО ОКНАМ</div>
                                <div class="es2_okna_tsena">
                                    <div class="es2_okna_right">2770 <span>р.</span></div>
                                </div>
    
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right"> 1240 <span>р.</span></div>
                                </div>
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">Германия</div>
                                </div>
    
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                    </div>
                                </div>
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">3 стекла</div>
                                </div>
                               
    
                            </div>
                            <div class="es2_okna slide">
                                <div class="es2_okna__zag">ПЕРЕКУПЩИКИ</div>
                                <div class="es2_okna_tsena">
                                    <div class="es2_okna_right">3100 <span>р.</span></div>
                                </div>
    
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">1350 <span>р.</span></div>
                                </div>
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">Китай</div>
                                </div>
    
    
    
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                    </div>
                                </div>
                                
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">3 стекла</div>
                                </div>
    
                            </div>
    
                            <div class="es2_okna slide">
                                <div class="es2_okna__zag">ЧАСТНЫЕ МАСТЕРА</div>
                                <div class="es2_okna_tsena">
                                    <div class="es2_okna_right">2900 <span>р.</span></div>
                                </div>
    
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">990 <span>р.</span></div>
                                </div>
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">Разные</div>
                                </div>
    
    
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                    </div>
                                </div>
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">2 стекла</div>
                                </div>
    
    
                            </div>
                            <div class="es2_okna slide">
                                <div class="es2_okna__zag">МЕГА БРЕНДЫ</div>
                                <div class="es2_okna_tsena">
                                    <div class="es2_okna_right">4200 <span>р.</span></div>
                                </div>
    
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">2100 <span>р.</span></div>
                                </div>
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">Германия</div>
                                </div>
    
    
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                        <img src="img/es11_star.png" alt="">
                                    </div>
                                </div>
                                <div class="es2_okna_row">
                                    <div class="es2_okna_row_right">2 стекла</span></div>
                                </div>
    
                            </div>
    
                        </div><!-- /.slider -->
                    </div>
                </div>
                <!-- /.es2_block -->
            </div>
        </div><!-- /.es2 -->