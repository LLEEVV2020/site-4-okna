        <div class="es4_balcons template">
            <div class="container">
                <div class="h2">
                    ОСТЕКЛИТЕ БАЛКОН ПО НИЗКОЙ ЦЕНЕ
                </div>
                <section class="regular2 slider">
                        <div >
                            <div class="item">
                                <div class="box1">
                                    <img src="img/balcony_glazing1.png">
                                </div>
                                <div class="box2">
                                    <div class="name"><span>ЛОДЖИЯ</span> 2 ЭРКЕРА</div>
                                    <div class="price">4750 Р</div>
                                    <div class="savings">
                                        <span>Ваша экономия</span>
                                        <span>1250 Р</span>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div >
                            <div class="item">
                                <div class="box1">
                                    <img src="img/balcony_glazing2.png">
                                </div>
                                <div class="box2">
                                    <div class="name"><span>П-ОБРАЗНЫЙ</span>  БАЛКОН</div>
                                    <div class="price">6050 Р</div>
                                    <div class="savings">
                                        <span>Ваша экономия</span>
                                        <span>1600 Р</span>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div >
                            <div class="item">
                                <div class="box1">
                                    <img src="img/balcony_glazing1.png">
                                </div>
                                <div class="box2">
                                    <div class="name"><span>ЛОДЖИЯ</span> 2 ЭРКЕРА</div>
                                    <div class="price">4750 Р</div>
                                    <div class="savings">
                                        <span>Ваша экономия</span>
                                        <span>1250 Р</span>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div >
                            <div class="item">
                                <div class="box1">
                                    <img src="img/balcony_glazing2.png">
                                </div>
                                <div class="box2">
                                    <div class="name"><span>П-ОБРАЗНЫЙ</span>  БАЛКОН</div>
                                    <div class="price">6050 Р</div>
                                    <div class="savings">
                                        <span>Ваша экономия</span>
                                        <span>1600 Р</span>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        
                    </section>

                    <p>Балконы по действующей акции
                        <button class="red-button" type="submit">ЗАКАЗАТЬ</button>
                    </p>
                    

            </div>
            

            <script>
                // ОСТЕКЛИТЕ БАЛКОН ПО НИЗКОЙ ЦЕНЕ
                $(document).ready(function(){
                    $(".regular2").slick({
                        dots: false,
                        infinite: true,
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        responsive: [
                            {
                            breakpoint: 1200,
                                settings: {
                                    slidesToShow: 1,
                                    slidesToScroll: 1
                                }
                            }
                        ]
                    });
                });
            </script>
        </div>

