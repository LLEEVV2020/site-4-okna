       
        <div class="es12_bg">

            <div class="h2">
                ВЫ НЕ БУДЕТЕ ПЕРЕПЛАЧИВАТЬ ЗА:
            </div>

            <div class="container">
                <div class="es12__block">

                    <div class="es12_item">
                        <div class="es12_ico">
                            <div class="es12_ico__img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es12_ico1.png" alt="" /></div>
                            <div class="es12_ico__lenta">экономия
                                <span>1 250 р.</span>
                            </div>
                        </div>
                        <div class="es12_ico_name">НЕНУЖНЫЕ БРЕНДЫ</div>
                    </div>
                    <div class="es12_item _top">
                        <div class="es12_ico">
                            <div class="es12_ico__img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es12_ico4.png" alt="" /></div>
                            <div class="es12_ico__lenta">экономия
                                <span>2 100 р.</span>
                            </div>
                        </div>
                        <div class="es12_ico_name">НЕНУЖНЫЕ РАБОТЫ</div>
                    </div>
                    <div class="es12_item">
                        <div class="es12_ico">
                            <div class="es12_ico__img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es12_ico3.png" alt="" /></div>
                            <div class="es12_ico__lenta">экономия
                                <span>900 р.</span>
                            </div>
                        </div>
                        <div class="es12_ico_name">НЕНУЖНЫЕ ФУНКЦИИ</div>
                    </div>
                    <div class="es12_item">
                        <div class="es12_ico">
                            <div class="es12_ico__img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es12_ico2.png" alt="" /></div>
                            <div class="es12_ico__lenta">экономия
                                <span>1 700 р.</span>
                            </div>
                        </div>
                        <div class="es12_ico_name">НЕНУЖНЫЕ МАТЕРИАЛЫ</div>
                    </div>
                </div>
            </div>


        </div>