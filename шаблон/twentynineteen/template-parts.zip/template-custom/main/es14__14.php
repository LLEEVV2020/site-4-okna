<div class="es14_bg_custom">
            <div class="h2">
                ОТЗЫВЫ НАШИХ ЗАКАЗЧИКОВ
            </div>
            <div class="container">
                <section class="regular slider">
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Ольга Иваненко</h5>
                                <p>Не могла долго решиться на такой глобальный для меня проект, как объединение балкона с комнатой, но все окаазалось гораздо проще, чем я представляла! Компания “Балконы цены” решила мой вопрос всего за две недели! Теперь у меня большая комната. 
                                        </p>
                            </div>
                        </div>
                        
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Максим Гладков </h5>
                                <p>Не могла долго решиться на такой глобальный для меня проект, как объединение балкона с комнатой, но все окаазалось гораздо проще, чем я представляла! Компания “Балконы цены” решила мой вопрос всего за две недели! Теперь у меня большая комната. </p>
                            </div>
                        </div>
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Вероника Сыроварова </h5>
                                <p>Не могла долго решиться на такой глобальный для меня проект, как объединение балкона с комнатой, но все окаазалось гораздо проще, чем я представляла! Компания “Балконы цены” решила мой вопрос всего за две недели! Теперь у меня большая комната. </p>
                            </div>
                        </div>
                        
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Регина Казанцева </h5>
                                <p>Не могла долго решиться на такой глобальный для меня проект, как объединение балкона с комнатой, но все окаазалось гораздо проще, чем я представляла! Компания “Балконы цены” решила мой вопрос всего за две недели! Теперь у меня большая комната.  </p>
                            </div>
                        </div>
                        
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Егор Василевич </h5>
                                <p>Не могла долго решиться на такой глобальный для меня проект, как объединение балкона с комнатой, но все окаазалось гораздо проще, чем я представляла! Компания “Балконы цены” решила мой вопрос всего за две недели! Теперь у меня большая комната.  </p>
                            </div> 
                        </div>
                        
                    </div>
                    <div >
                        <div class="item-rewiews">
                            <div class="box1">
                                <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/reviews1.png">
                            </div>
                            <div class="box2">
                                <h5>Ольга Иваненко</h5>
                                <p>Не могла долго решиться на такой глобальный для меня проект, как объединение балкона с комнатой, но все окаазалось гораздо проще, чем я представляла! Компания “Балконы цены” решила мой вопрос всего за две недели! Теперь у меня большая комната. 
                                        </p>
                            </div>
                        </div>
                        
                    </div>
                </section>
            </div>
        </div>

        <script src="//<?php echo $_SERVER['SERVER_NAME']; ?>/js/slick.min.js"></script>
 <script type="text/javascript">
            $(document).ready(function(){
                $(".regular").slick({
                    dots: true,
                    arrows: false,
                    infinite: true,
                    slidesToShow: 2,
                    slidesToScroll: 2,
                    responsive: [
                        {
                        breakpoint: 1200,
                            settings: {
                                slidesToShow: 1,
                                slidesToScroll: 1
                            }
                        }
                    ]
                });
            });
            
        </script>