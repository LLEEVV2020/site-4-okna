 <div class="b_windownow_bg rast_windownow_bg  es5_balcons template">
    
    <div class="container">

        <div class="flex-container">
            <div class="b_windownow_man"><img src="img/rasr_gerl2.png" alt=""></div>
            <div class="b_windownow_block">
                <h4>ОСТЕКЛЕНИЕ БЕСПЛАТНО!</h4>
                
                <p>Оформите дисконтную карту и верните все деньги за остекление своего балкона!</p>  

                <a href="remont-kvartir-rassrochka/index.html" class="red-button">ОФОРМИТЬ СЕЙЧАС</a>
                        
            </div>
            
        </div> 

    </div><!-- /.container -->

</div>