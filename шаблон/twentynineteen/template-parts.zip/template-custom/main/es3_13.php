     <div class="es3">
            <div class="container">
                <div class="es3__block">
                    <div class="es3__ttl">Нашли ещё дешевле?</div>
                    <div class="es3__ttl_2">
                       <i>Вернём</i> 
                        <div class="interest-ib">120%</div>
                        <i>от разницы</i> 
                    </div>
                    
                    
                    <div class="es3__info">Если Вам предложили в другой компании цену ниже на идентичный шкаф, то предоставьте нам смету, и мы гарантируем, что предложим вам еще более низкую цену! <br></div>
                    
                    <div class="es3__phone_ttx">Индивидуальная скидка по телефону:</div>
                    <div class="es3__phone_number">
                        <a style="text-decoration:none;color: #1a1918" href="tel:<?php if(empty(get_option('my_phone')) ){
                                                          echo "8 (495) 106-48-55";
                                                      }
                                                      else{
                                                          echo get_option('my_phone'); 
                                                      } ?>">
                            <span class="comagic_phone"> <?php if(empty(get_option('my_phone')) ){
                                                          echo "8 (495) 106-48-55";
                                                      }
                                                      else{
                                                          echo get_option('my_phone'); 
                                                      } ?></span>
                        </a>
                    </div>
                   

                </div>

            </div>
        </div>
        <!--es3-->