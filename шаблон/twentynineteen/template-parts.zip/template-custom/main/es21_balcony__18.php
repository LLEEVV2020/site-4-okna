
        <div class="template es21_balcony">
            <div class="container">
                <div class="flex-wrapper">
                    <div class="item"> Остекление <br>    
                        балконов</div>
                    <div class="item">Отделка <br>
                        балконов</div>
                    <div class="item">Готовые  <br>
                        балконы</div>
                    <div class="item">Цены <br>
                         на балконы</div>
                </div>   
            </div>
        </div>