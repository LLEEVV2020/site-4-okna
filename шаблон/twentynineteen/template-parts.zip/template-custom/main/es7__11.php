        <div class="es7" style="padding: 40px 0 10px;">
            
            <div class="container flex-container ">

                <div class="item">
                
                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es7_ico1.png" alt="">
                    <div class="item-text">
                        <h4 class="media-heading">Бесплатный замер</h4>
                        <div>В компании "Балконы Цены" все замеры бесплатные! 
                            Замерщик приедет к Вам в любое место и время и посоветует оптимальные материалы.</div>
                    </div>
                                  
                </div>

                <div class="item">
                    
                    <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/es7_ico2.png" alt="">
                    <div class="item-text">
                        <h4 class="media-heading">Рассрочка 0%</h4>
                        <div>В "Балконы Цены" беспроцентная рассрочка сроком до 3х лет с минимальным первоначальным взносом.</div>
                    </div>
                   
                
                </div>

            </div><!-- /.container -->

        </div>