 <!-- quick-calculation10 -->
        <div class="quick-calculation es8_balcons template">
            <div class="container">
                <div class="h2">ПРИ ЗАКАЗЕ ВЫ ПОЛУЧАЕТЕ</div>
                <div class="flex-container">
                    <div class="item item-1">
                        <div class="es2_but" data-toggle="modal" data-target="#kupitDeshevle">ТЕПЛЫЙ ПОЛ <br>
                            ОТ 640 Р</div>
                    </div>
                    <div class="item item-2">
                        <div class="es2_but" data-toggle="modal" data-target="#kupitDeshevle">УТЕПЛЕНИЕ БАЛКОНА
                            <br> ОТ 420 Р</div>
                    </div>
                    <div class="item item-3">
                        <div class="es2_but" data-toggle="modal" data-target="#kupitDeshevle">ОБЪЕДИНЕНИЕ БАЛКОНА
                            <br> ОТ 990 Р</div>
                    </div>
                </div>
            </div>
            
        </div>