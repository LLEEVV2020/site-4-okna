   <div class="contact-wrap template contact-wrap-balcon">
            <div class="container">
                <h2>РАБОТАЕМ ПО ВСЕМУ МОСКОВСКОМУ И ОБЛАСТИ:</h2>

                <div class="flex-container vcard">
                    
                    <div class="block-item">
                        <div class="block-img">
                            <img src="img/contact-tel2.png" alt="">
                        </div>
                        <div class="item item-main">
                           
                           <div>Звоните ежедневно <br>с 8:00 до 23:00</div>
                           
                            
                            <div class="tel"> <abbr class="value" title="8 (495) 106-48-55">8 (495) 106-48-55</abbr></div>
                            <p class="email">zakaz@shkaf-tseny.ru</p>
                        </div>
                    </div>
                    <div class="block-item">
                        <div class="block-img">
                            <img src="img/ykazatel.png" alt="">
                        </div>
                        <div class="item">
                            <div class="head">Центральный офис</div>
                            <p class="workhours">Москва, Варшавское шоссе,
д.33, этаж 4, офис 13, рядом со
станцией метро Нагатинская</p>
                        </div>
                    </div>
                    
                    
                    <div class="block-item">
                        <div class="block-img">
                            <img src="img/rekvizits.png" alt="">
                        </div>
                        <div class="item">
                            <div class="head">Реквизиты</div>
                            <p class="email">ООО “Надежный выбор”<br>
ИНН 7726370558 <br>
ОГРН 1167746224095 <br>
Р/С 40702810038000019853</p>
                        </div>
                    </div>
                </div>


            </div>
        </div>