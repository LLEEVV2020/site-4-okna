<!-- windows_free -->
<div class="b-rassr">
    <div class="container">
            
        <h2>УСЛОВИЯ ДЛЯ РАССРОЧКИ И КРЕДИТА</h2>
        
        <div class="row ">
            
            <div class=" b-rassr__ico"><span>1</span></div>
            <div class="">
                <div class="b-rassr__b1">ВЫ МОЖЕТЕ ЗАКАЗАТЬ БАЛКОН, НЕ ИМЕЯ НА МОМЕНТ ЗАКАЗА НЕОБХОДИМОЙ СУММЫ.</div>

                <div class="b-rassr__b2">Вы будете знать точный размер ежемесячного платежа и при возможности сможете погашать платежи досрочно.</div>
            </div>
            
        </div>
        
        
        
        <div class="row ">
            
            <div class=" b-rassr__ico"><span>2</span></div>
            <div class="">
                <div class="b-rassr__b1">ВЫ САМИ ВЫБИРАЕТЕ ОПТИМАЛЬНЫЙ ДЛЯ ВАС ВАРИАНТ РАССРОЧКИ ИЛИ КРЕДИТОВАНИЯ. НАШИ СПЕЦИАЛИСТЫ ВСЕГДА ГОТОВЫ ПОМОЧЬ ВАМ РАЗОБРАТЬСЯ В ЭТОМ ВОПРОСЕ.</div>

                <div class="b-rassr__b2">Вам не нужно посещать банк для выяснения возможности получение кредита. Мы сэкономим ваше время и узнаем всю необходимую информацию для Вас! </div>
            </div>
           
        </div>
        
        
        <div class="row ">
            
            <div class=" b-rassr__ico"><span>3</span></div>
            <div class="">
                <div class="b-rassr__b1">БАНК РАССМОТРИТ ВАШУ ЗАЯВКУ В ТЕЧЕНИЕ 15 МИН.! </div>

                <div class="b-rassr__b2">Процесс рассмотрения и оформления заявки на выдачу рассрочки или кредита занимает минимум времени, что опять же экономит Ваше время! </div>
            </div>
            
        </div>
        
        
        <br>
        
        <div class="b-rassr__text">Остались вопросы? Более подробную  информацию и ответы на интересующие вас вопросы Вы можете получить по тел.:  <a style="text-decoration:none;color: #1a1918" href="tel:8 (8617) 77-01-01"><span class="comagic_phone"><?php if(empty(get_option('my_phone')) ){
                                                          echo "8 (495) 106-48-55";
                                                      }
                                                      else{
                                                          echo get_option('my_phone'); 
                                                      } ?></span></a></div>
        
        
    </div>
        
  </div><!-- b-rassr -->