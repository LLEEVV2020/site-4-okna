            <div class="es1 _main rassr_bg rassr_balcons">
                <div class="container">
                     
                    <div class="es1__block">
                        <h1>БАЛКОНЫ
<span>В РАССРОЧКУ БЕЗ</span>
<span class="decor_0">ПЕРЕПЛАТЫ</span></h1>
                        <div class="es1__menu">
                            <div class="es1__menu_item lbl1"><span>На срок от 3 до 36 месяцев</span></div>
                            <div class="es1__menu_item lbl2"><span>Оформление за 15 минут</span></div>
                            <div class="es1__menu_item lbl3"><span>Без предоплаты</span></div>
    
                        </div>
    
                        <div class="text">Сотрудничество с банками "Альфа-Банк" и "Кредит Европа Банк" на протяжении
                            долгих лет позволило создать для Вас ВЫГОДНЫЕ УСЛОВИЯ ПО КРЕДИТОВАНИЮ</div>
                        
                        <div class="banks">
                            <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/rasr_evrbank.png" alt="">
                            <img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/rasr_alfabank.png" alt="">
                        </div>    
                    </div>
                </div>
            </div>