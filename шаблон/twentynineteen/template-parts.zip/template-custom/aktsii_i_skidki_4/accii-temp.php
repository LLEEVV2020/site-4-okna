  <!-- Самый верхний блок -->
        <div class="es1 _main template finishing_balconies accii_temp">
            <div class="container">
               
                <div class="es1__block">
                    <h1>СКИДКА НА ОТДЕЛКУ
                        
                        <span>БАЛКОНОВ</span>
                        </h1>
                        <div class="action-img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/accii.png" alt=""></div>
                    
                </div>

              

            </div>
        </div>
        <!--/ Самый верхний блок -->