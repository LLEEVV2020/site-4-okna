<div class="es1 _main  block-action">
            <div class="container" style="height: 100%;">
                <div class="es1__pict"></div>
                <div class="es1__block">
                    <h1>ЛЮБОЙ 
                        <span>ВСТРОЕННЫЙ </span>
                        <span>ШКАФ-КУПЕ</span>
                        СО СКИДКОЙ</h1>
                        <div class="action-img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/accii.png" alt=""></div>
                    
                </div>
            </div>
        </div>