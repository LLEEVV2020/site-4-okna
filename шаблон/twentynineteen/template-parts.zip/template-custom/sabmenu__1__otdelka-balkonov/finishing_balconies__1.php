  <!-- Самый верхний блок -->
        <div class="es1 _main template finishing_balconies">
            <div class="container">
                <div class="es1__pict"></div>
                <div class="es1__block">
                    <h1>СКИДКА НА ОТДЕЛКУ
                        
                        <span>БАЛКОНОВ</span>
                        </h1>
                        <div class="action-img"><img src="//<?php echo $_SERVER['SERVER_NAME']; ?>/img/accii.png" alt=""></div>
                    
                </div>

                <div class="es1-flex-wrap">
                    <div class="b-top__zamer block-calculate" data-toggle="modal" data-target="#want_zamer">
                        <div class="b-top__zamer_ruler "></div>
                        <div class="b-top__zamer_txt"><span>РАССЧИТАТЬ</span><br>
                            по самой низкой цене</div>
                    </div>
                    <div class="name-abs">
                        <span>Мастер</span>
                        <span>
                            Василий Скворцов</span>
                    </div>
                    <div class="b-top__zamer" data-toggle="modal" data-target="#want_zamer">
                        <div class="b-top__zamer_ruler "></div>
                        <div class="b-top__zamer_txt"><span>БЕСПЛАТНЫЙ</span><br>
                            выезд замерщика</div>
                    </div>
                </div>

            </div>
        </div>
        <!--/ Самый верхний блок -->